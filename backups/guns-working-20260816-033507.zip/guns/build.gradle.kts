dependencies {
    compileOnly(project(":"))
}
